# PalindromeApp
Repository for a simple native Android app with 3 pages developed using Kotlin.

This project uses Retrofit2 library to configure HTTP Requests into reqres.in API endpoint. It also utilizes Paging3 to take multiple pages of data from the API and display it in a vertical list. The Glide library was also used to load images from their respective URLs.


